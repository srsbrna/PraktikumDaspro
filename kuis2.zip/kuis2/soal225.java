
import java.util.Scanner;

//Sarah Sabrina K (25/254106070085)

public class soal225 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String[] nama = {"Pensil", "Pulpen", "Buku", "Penghapus", "Penggaris"};
        int[] harga = {2000, 3000, 5000, 1500, 2500};

        System.out.println("=== Daftar Barang Toko ===");
        for (int i = 0; i < nama.length; i++) {
            System.out.println((i + 1) + ". " + nama[i] + " - Rp " + harga[i]);
        }

        System.out.print("\nMasukkan nama barang yang dicari: ");
        String cari = sc.nextLine(); // input barang yang akan dicari

        int index = -1;
        for (int i = 0; i < nama.length; i++) {
            if (nama[i].equalsIgnoreCase(cari)) {
                index = i;
                break;
            }
        }

        // Hasil
        if (index != -1) {
            System.out.println("Barang ditemukan!");
            System.out.println("Nama : " + nama[index]);
            System.out.println("Harga: Rp " + harga[index]);
        } else {
            System.out.println("Barang tidak tersedia di toko.");
        }

        sc.close();
    }
}
